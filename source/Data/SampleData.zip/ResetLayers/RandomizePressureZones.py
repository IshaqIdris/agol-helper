#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Mike
#
# Created:     03/02/2014
# Copyright:   (c) Mike 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import datetime
import time
from random import randint

def main():
    datafile = open("PressureData.csv", "w")
    datafile.write("ID,PSI,PRESSUREDATE")
    datafile.write("\n")
    tm =  datetime.datetime.now().strftime("%m/%d/%Y %I:%M:%S %p")
    for x in range(1,7):
        datafile.write(str(x) +"," + str(randint(20,100)) + "," + tm)
        datafile.write("\n")

    datafile.flush()
    del(datafile)
if __name__ == '__main__':
    main()
